/**
 * Support for migrating from JUnit 4 to JUnit Jupiter.
 */

package org.junit.jupiter.migrationsupport;
