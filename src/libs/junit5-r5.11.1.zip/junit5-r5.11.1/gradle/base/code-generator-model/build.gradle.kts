plugins {
    `kotlin-dsl`
}

group = "junitbuild.base"

repositories {
    gradlePluginPortal()
}
