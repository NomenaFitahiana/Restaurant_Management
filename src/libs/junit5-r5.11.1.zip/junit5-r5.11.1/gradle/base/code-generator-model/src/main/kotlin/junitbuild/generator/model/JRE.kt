package junitbuild.generator.model

data class JRE(val version: Int, val since: String?)
